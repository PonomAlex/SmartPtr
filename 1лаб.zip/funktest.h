#pragma once
#include "smart_ptr.h"
#include <iostream>
#include <cassert>

void funkTest();